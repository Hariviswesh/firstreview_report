package com.demo.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.*;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	
	  public RegistrationServlet() { 
		  
		  super(); // TODO Auto-generated constructor
	  }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/*
	 * protected void doGet(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { Connection con = null;
	 * ResultSet rs; try { System.out.print("hai"); String vid =
	 * request.getParameter("id"); System.out.print(vid); int
	 * id=Integer.parseInt(vid); System.out.print(id);
	 * Class.forName("com.mysql.cj.jdbc.Driver"); con = DriverManager.getConnection(
	 * "jdbc:mysql://localhost:3306/project?useSSL=false", "root",
	 * "Hari_viswesh@1999"); PreparedStatement pst = con.prepareStatement(
	 * "SELECT * FROM project.vendor_details WHERE vendor_id=?"); pst.setInt(1, id);
	 * rs=pst.executeQuery(); while(rs.next()){ JSONObject obj = new JSONObject();
	 * 
	 * }
	 * 
	 * } catch (Exception e) { e.printStackTrace();
	 * 
	 * } finally { try { con.close(); } catch (SQLException e) {
	 * e.printStackTrace(); } }
	 * 
	 * 
	 * }
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		String registerForm = "./pages/form-validation.jsp";
//		RequestDispatcher dispatcher = request.getRequestDispatcher(registerForm);
//		dispatcher.forward(request, response);

//		String Vendorid=request.getParameter("Vendorid");

		String cname = request.getParameter("cname");
		String warehouse = request.getParameter("warehouse");
		String status = request.getParameter("status");
		String vendor_type = request.getParameter("vendor_type");
		String vendorsub_type = request.getParameter("vendorsub_type");
		String address = request.getParameter("address");
		String VendorISAtag = request.getParameter("VendorISAtag");
		String ERPVendorid = request.getParameter("ERPVendorid");
		String SenderID = request.getParameter("SenderID");
		String VendorTaxID = request.getParameter("VendorTaxID");
		RequestDispatcher dispatcher = null;
		Connection con = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		String wareid;
		String warename = null;
		try {
			System.out.print("hai");
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?useSSL=false", "root",
					"Hari_viswesh@1999");
			statement=con.createStatement();
			String sql = "select * from `project`.`ware_house` where ware_house_id=?";
			PreparedStatement pstr = con.prepareStatement(sql);
			pstr.setString(1, warehouse);
			resultSet = pstr.executeQuery();
			while (resultSet.next()) {

				warename=resultSet.getString("ware_house_name");
				// System.out.println(rs.getString(1));
			}
			
			PreparedStatement pst = con.prepareStatement(
					"INSERT INTO `project`.`vendor_details`(`Company_name`,`warehouse`,`Vendor_type`,`vendor_sub_type`,`address`,`vendor_isatag`,`erp_vendorid`,`sender_id`,`vendor_tax_id`,`warehouse_id`) VALUES (?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, cname);
			pst.setString(2, warename);
			pst.setString(3, vendor_type);
			pst.setString(4, vendorsub_type);
			pst.setString(5, address);
			pst.setString(6, VendorISAtag);
			pst.setString(7, ERPVendorid);
			pst.setString(8, SenderID);
			pst.setString(9, VendorTaxID);
			pst.setString(10, warehouse);
			int rowCount = pst.executeUpdate();
			dispatcher = request.getRequestDispatcher("form-validation.jsp");
			if (rowCount > 0) {
				request.setAttribute("status", "success");
			} else {
				request.setAttribute("status", "failed");

			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
